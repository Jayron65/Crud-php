<?php  

include_once'conexao.php';
$cod = $_POST['codigo'];
$desc = $_POST['descricao'];
@$quant = $_POST['localidade'];

$sql = "INSERT INTO livros (codigo,descricao,localidade) VALUES ('$cod','$desc', '$local')";
$r = mysqli_query($con,$sql);

if($r){
	echo "cadastrado com sucesso";
}else{
	echo "errro ao cadastrar";
}

?>