<?php  
$host="localhost";
$nome="root";
$senha ="usbw";
$banco = "mercadorias";

$con = mysqli_connect($host,$nome,$senha,$banco);
if($con){
	
}else{
	
} 

?>