<!DOCTYPE html>
<html>
<head>
	<title>Deletar</title>
	<meta charset="utf-8"/>
</head>
<body>
<form method="POST" action="Deletar.php">
		Digite o numero do aluno : <input type="text" name="delet" id="delet">
		<p><input type="submit" name="Deletar" value="Deletar"></p>



</form>
</body>
</html>