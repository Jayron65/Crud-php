<!DOCTYPE html>
<html>
<head>
	<title>index</title>
	<meta charset="utf-8"/>
	<style type="text/css">
		#tabela{
			margin-top: 400px;
		}
		a {
			color: white;
			text-decoration: none;
		}
	</style>
</head>
<body bgcolor="">

	<h1 align="center" id="tabela">Cadastro De Meracdorias</h1>
	
		<a href="cadastro.php">Mercadorias</a></td>
		<a href="listar.php" >Listar Mercadorias</a></td>
	

</body>
</html>